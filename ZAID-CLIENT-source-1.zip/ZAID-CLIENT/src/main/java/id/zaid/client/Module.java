package id.zaid.client;

public final class Module {
    public final String name;
    public final String description;
    public boolean enabled;
    public final Runnable onEnable;
    public final Runnable onDisable;

    public Module(String name, String description, Runnable onEnable, Runnable onDisable) {
        this.name = name;
        this.description = description;
        this.onEnable = onEnable == null ? () -> {} : onEnable;
        this.onDisable = onDisable == null ? () -> {} : onDisable;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable.run(); else onDisable.run();
        Config.save();
    }
}
