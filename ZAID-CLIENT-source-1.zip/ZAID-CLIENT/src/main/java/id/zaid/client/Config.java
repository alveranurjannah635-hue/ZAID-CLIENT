package id.zaid.client;

import net.minecraft.client.MinecraftClient;
import java.io.*;
import java.nio.file.*;

public final class Config {
    private static final Path FILE = MinecraftClient.getInstance().runDirectory.toPath()
            .resolve("config").resolve("zaidclient.properties");
    public static boolean hudEnabled = true;
    public static boolean showEnabledModules = true;
    public static double gamma = 1.0;

    private Config() {}

    public static void load() {
        PropertiesCompat p = new PropertiesCompat();
        try {
            if (Files.exists(FILE)) p.load(Files.newInputStream(FILE));
            gamma = Double.parseDouble(p.get("gamma", "1.0"));
            showEnabledModules = Boolean.parseBoolean(p.get("showModules", "true"));
            for (Module m : Modules.ALL) m.enabled = Boolean.parseBoolean(p.get(m.name, m.name.equals("HUD") ? "true" : "false"));
        } catch (Exception ignored) {
            // Invalid config is ignored; no network or personal data is accessed.
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            PropertiesCompat p = new PropertiesCompat();
            p.set("gamma", Double.toString(gamma));
            p.set("showModules", Boolean.toString(showEnabledModules));
            for (Module m : Modules.ALL) p.set(m.name, Boolean.toString(m.enabled));
            try (Writer w = Files.newBufferedWriter(FILE)) { p.store(w); }
        } catch (IOException e) {
            System.err.println("[ZAID CLIENT] Could not save config: " + e.getMessage());
        }
    }

    private static final class PropertiesCompat {
        private final java.util.Properties data = new java.util.Properties();
        void load(InputStream in) throws IOException { try (in) { data.load(in); } }
        String get(String key, String fallback) { return data.getProperty(key, fallback); }
        void set(String key, String value) { data.setProperty(key, value); }
        void store(Writer writer) throws IOException { data.store(writer, "ZAID CLIENT local settings"); }
    }
}
