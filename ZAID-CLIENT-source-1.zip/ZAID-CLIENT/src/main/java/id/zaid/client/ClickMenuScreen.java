package id.zaid.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ClickMenuScreen extends Screen {
    private int scroll;

    public ClickMenuScreen() { super(Text.literal("ZAID CLIENT")); }

    @Override
    protected void init() {
        int left = this.width / 2 - 105;
        int top = Math.max(42, this.height / 2 - 90);
        int i = 0;
        for (Module module : Modules.ALL) {
            final Module selected = module;
            addDrawableChild(ButtonWidget.builder(label(selected), b -> {
                selected.toggle();
                b.setMessage(label(selected));
            }).dimensions(left, top + i * 27, 210, 22).build());
            i++;
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left, top + i * 27 + 5, 210, 22).build());
    }

    private Text label(Module m) {
        return Text.literal((m.enabled ? "●  " : "○  ") + m.name)
                .styled(s -> s.withColor(m.enabled ? 0xFFFF5555 : 0xFFE8E8E8));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = width / 2 - 125, top = Math.max(24, height / 2 - 120);
        context.fill(left, top, left + 250, top + 250, 0xE8101010);
        context.fill(left, top, left + 250, top + 3, 0xFFFF3030);
        context.drawCenteredTextWithShadow(textRenderer, "ZAID CLIENT", width / 2, top + 12, 0xFFFF4040);
        context.drawCenteredTextWithShadow(textRenderer, "RIGHT SHIFT  •  CLICK MODULE TO TOGGLE",
                width / 2, top + 27, 0xFFAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
